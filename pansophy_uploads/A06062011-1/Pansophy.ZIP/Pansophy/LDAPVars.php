<?php
// Michael Thompson * 12/16/2005 * Created to enable the contexts to be looked up automatically
// This is a general user with read access to everything
 $LdapServer   = "ldap.wooster.edu";
 $LdapUser     = "xxx";
 $LdapPassword = "xxx";
 $LdapBase     = "o=wooster";

?>
