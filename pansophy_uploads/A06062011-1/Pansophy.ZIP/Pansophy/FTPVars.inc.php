<?php

/**
 * Stores FTP server information
 */

 $FtpServer   = "140.103.60.251";
 $FtpUser     = "xxx";
 $FtpPassword = "xxx";

?>