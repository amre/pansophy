<?php
/**this is an easter egg.
*it will only be used if an issue with the header "badgerphone" is created
**/

echo '<center><object width="550" height="400">
<param name="movie" value="http://www.terminalpacketloss.com/hosted/badgerphone/badgerphone.swf">
<embed src="http://www.terminalpacketloss.com/hosted/badgerphone/badgerphone.swf" width="550" height="400">
</embed>
</object></center>';
?>
